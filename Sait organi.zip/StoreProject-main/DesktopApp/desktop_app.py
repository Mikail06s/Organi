"""Desktop wrapper for the StoreProject Django shop."""
import os
import sys
import time
import socket
import subprocess
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP_DIR = ROOT / 'OnlineStore'
HOST = '127.0.0.1'
PORT = 8765
URL = f'http://{HOST}:{PORT}/'


def port_ready(host, port, timeout=45):
    end = time.time() + timeout
    while time.time() < end:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.4)
    return False


def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'OnlineStore.settings')
    env = os.environ.copy()
    env['PYTHONPATH'] = str(APP_DIR) + os.pathsep + env.get('PYTHONPATH', '')
    manage = APP_DIR / 'manage.py'
    creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0

    # Prepare local database and bundled demo catalog on first launch.
    subprocess.run([sys.executable, str(manage), 'migrate', '--noinput'], cwd=APP_DIR, env=env, check=True, creationflags=creationflags)
    marker = APP_DIR / '.catalog_loaded'
    if not marker.exists():
        result = subprocess.run([sys.executable, str(manage), 'loaddata', 'data.json'], cwd=APP_DIR, env=env, creationflags=creationflags)
        if result.returncode == 0:
            marker.write_text('loaded', encoding='utf-8')

    server = subprocess.Popen([sys.executable, str(manage), 'runserver', f'{HOST}:{PORT}', '--noreload'], cwd=APP_DIR, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=creationflags)
    try:
        if not port_ready(HOST, PORT):
            raise RuntimeError('Не удалось запустить локальный магазин. Проверьте Python и зависимости.')
        try:
            import webview
            webview.create_window('StoreProject — магазин', URL, width=1280, height=820, min_size=(900, 600))
            webview.start()
        except ImportError:
            webbrowser.open(URL)
            print('Магазин открыт в браузере. Закройте это окно, чтобы остановить сервер.')
            server.wait()
    finally:
        server.terminate()
        try:
            server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server.kill()


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'Ошибка запуска: {exc}')
        input('Нажмите Enter для выхода...')
