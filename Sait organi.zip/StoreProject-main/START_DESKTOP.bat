@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ===============================================
echo       StoreProject - Desktop application
echo ===============================================
where python >nul 2>nul
if errorlevel 1 (
  echo Python не найден. Установите Python 3.10 или 3.11 с сайта https://www.python.org/downloads/
  echo При установке обязательно отметьте Add Python to PATH.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  echo Создаю виртуальное окружение...
  python -m venv .venv
  if errorlevel 1 (pause & exit /b 1)
)
echo Устанавливаю зависимости. При первом запуске требуется интернет...
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements-desktop.txt
if errorlevel 1 (
  echo Не удалось установить зависимости. Проверьте подключение к интернету и версию Python.
  pause
  exit /b 1
)
.venv\Scripts\python.exe DesktopApp\desktop_app.py
pause
